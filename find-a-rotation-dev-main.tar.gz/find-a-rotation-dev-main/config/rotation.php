<?php

return [
    'pagination_size' => env("PAGINATION_SIZE",20),
    'max_rotation_price' => env("MAX_ROTATION_PRICE",2500),
];
