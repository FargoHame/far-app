<x-app-layout>
    <!-- Metadata -->
    @section ('title', 'Dashboard | Find a Rotation')
</x-app-layout>