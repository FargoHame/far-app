<div class="squard">
    {{ $slot }}
</div>