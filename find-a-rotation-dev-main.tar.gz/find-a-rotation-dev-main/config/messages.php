<?php

return [
    'oauth-error' => 'You already have a FindARotation account under this email address.',
    'oauth-error-services' => 'You already have an account under this email address, but using a different service. Please use that service to log in.',
];
