<div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-far-green-light">
    <div class="w-full px-6">
        {{ $slot }}
    </div>
</div>
